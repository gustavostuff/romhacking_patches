Aside from the gender swap work I did, credit goes to:

Pennywise
 - all the original and difficult hacking
MFerraro (@mferraro.bsky.social)
 - new title screen animation
 - new translations
 - some additional hacking of a couple pointers
 and timers, and reverse-engineering the original hacks
 to build over them and separate the title screen.
